# Turing regenerated _2

Self-contained static package with copied real threads, regenerated fictitious threads, viewer assets, diagnostics, run manifest, and a snapshot of the generation script.
